const express = require('express');
const router = express.Router();
const { Product, Order, User, Settings, Category, Brand, Page } = require('./models');

// --- Middleware ---
// Ideally add Auth middleware (JWT) here for protected routes

// --- Products ---
router.get('/products', async (req, res) => {
  try {
    const products = await Product.find({ isActive: true });
    res.json(products);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/products/all', async (req, res) => {
    // Admin route: get all including inactive
    try {
      const products = await Product.find({});
      res.json(products);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/products', async (req, res) => {
  try {
    const newProduct = new Product(req.body);
    await newProduct.save();
    res.json(newProduct);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/products/:id', async (req, res) => {
    try {
        const updated = await Product.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
        res.json(updated);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/products/:id', async (req, res) => {
    try {
        await Product.deleteOne({ id: req.params.id });
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- Orders ---
router.post('/orders', async (req, res) => {
  try {
    const order = new Order(req.body);
    await order.save();
    // Send email logic here
    res.json(order);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/orders', async (req, res) => {
    try {
        const orders = await Order.find({}).sort({ date: -1 });
        res.json(orders);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- Settings ---
router.get('/settings', async (req, res) => {
    try {
        let settings = await Settings.findOne({ id: 'settings' });
        if (!settings) settings = new Settings({ id: 'settings' }); // Default
        res.json(settings);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/settings', async (req, res) => {
    try {
        const settings = await Settings.findOneAndUpdate({ id: 'settings' }, req.body, { upsert: true, new: true });
        res.json(settings);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;