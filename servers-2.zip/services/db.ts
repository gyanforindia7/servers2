
import { Product, Order, User, SiteSettings, Category, Brand, PageContent, ContactMessage, QuoteRequest, Coupon, BlogPost } from '../types';

/**
 * PRODUCTION DATABASE SERVICE
 * This file now points to your Node.js backend instead of local storage.
 */

const API_URL = '/api';

const apiRequest = async (endpoint: string, method: string = 'GET', body?: any) => {
    const headers: any = { 'Content-Type': 'application/json' };
    const config: RequestInit = { method, headers };
    if (body) config.body = JSON.stringify(body);
    
    try {
        const response = await fetch(`${API_URL}${endpoint}`, config);
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || `API Error: ${response.statusText}`);
        }
        return response.json();
    } catch (err) {
        console.error(`API Request failed (${endpoint}):`, err);
        throw err;
    }
};

export const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
};

// --- Products ---
export const getProducts = async (): Promise<Product[]> => apiRequest('/products');
export const getProductById = async (id: string): Promise<Product | undefined> => {
    const products = await getProducts();
    return products.find(p => p.id === id);
};
export const getProductBySlug = async (slug: string): Promise<Product | undefined> => {
    const products = await getProducts();
    return products.find(p => p.slug === slug);
};
export const getProductsByCategory = async (categoryName: string): Promise<Product[]> => {
    const products = await getProducts();
    return products.filter(p => p.category === categoryName && p.isActive !== false);
};
export const getSimilarProducts = async (currentProduct: Product): Promise<Product[]> => {
    const products = await getProducts();
    return products.filter(p => p.category === currentProduct.category && p.id !== currentProduct.id).slice(0, 5);
};
export const saveProduct = async (product: Product): Promise<void> => {
    if (product.id && !product.id.startsWith('p-new')) {
        await apiRequest(`/products/${product.id}`, 'PUT', product);
    } else {
        await apiRequest('/products', 'POST', { ...product, id: `p-${Date.now()}` });
    }
};
export const deleteProduct = async (id: string): Promise<void> => apiRequest(`/products/${id}`, 'DELETE');

// --- Categories ---
export const getCategories = async (): Promise<Category[]> => apiRequest('/categories');
export const saveCategory = async (cat: Category): Promise<void> => apiRequest('/categories', 'POST', cat);
export const deleteCategory = async (id: string): Promise<void> => apiRequest(`/categories/${id}`, 'DELETE');
// Fix: Added getCategoryBySlug
export const getCategoryBySlug = async (slug: string): Promise<Category | undefined> => {
    const categories = await getCategories();
    return categories.find(c => c.slug === slug);
};
export const getCategoryHierarchy = async (): Promise<Category[]> => {
    const allCats = await getCategories();
    return allCats.filter(c => !c.parentId); // Simplified for now
};

// --- Settings ---
export const getSiteSettings = async (): Promise<SiteSettings> => apiRequest('/settings');
export const saveSiteSettings = async (settings: SiteSettings): Promise<void> => apiRequest('/settings', 'POST', settings);

// --- Orders ---
export const createOrder = async (order: any): Promise<Order> => apiRequest('/orders', 'POST', order);
export const getOrders = async (): Promise<Order[]> => apiRequest('/orders');
export const getOrderById = async (id: string): Promise<Order | undefined> => {
    const orders = await getOrders();
    return orders.find(o => o.id === id);
};
export const getUserOrders = async (userId: string): Promise<Order[]> => {
    const orders = await getOrders();
    return orders.filter(o => o.userId === userId);
};
export const updateOrderStatus = async (id: string, status: string): Promise<void> => apiRequest(`/orders/${id}/status`, 'PATCH', { status });
// Fix: Added deleteOrder and cancelOrder
export const deleteOrder = async (id: string): Promise<void> => apiRequest(`/orders/${id}`, 'DELETE');
export const cancelOrder = async (id: string, reason: string): Promise<void> => apiRequest(`/orders/${id}/cancel`, 'PATCH', { reason });

// --- Auth ---
// Fix: authenticateUser is now async
export const authenticateUser = async (email: string, password: string): Promise<User | undefined> => {
    if (email === 'admin@serverpro.com' && password === 'ServerPro@2024') {
        return { id: 'admin', name: 'Super Admin', email, role: 'admin' };
    }
    return undefined;
};
export const getUsers = async (): Promise<User[]> => apiRequest('/users');
export const saveUser = async (user: User): Promise<void> => apiRequest('/users', 'POST', user);

// --- Misc ---
export const submitQuote = async (quote: any): Promise<void> => apiRequest('/quotes', 'POST', quote);
export const getQuotes = async (): Promise<QuoteRequest[]> => apiRequest('/quotes');
export const updateQuoteStatus = async (id: string, status: string): Promise<void> => apiRequest(`/quotes/${id}/status`, 'PATCH', { status });
export const deleteQuote = async (id: string): Promise<void> => apiRequest(`/quotes/${id}`, 'DELETE');

// Fix: Added submitContactMessage, getContactMessages, markMessageRead, deleteMessage
export const submitContactMessage = async (msg: any): Promise<void> => apiRequest('/contact', 'POST', msg);
export const getContactMessages = async (): Promise<ContactMessage[]> => apiRequest('/contact');
export const markMessageRead = async (id: string): Promise<void> => apiRequest(`/contact/${id}/read`, 'PATCH');
export const deleteMessage = async (id: string): Promise<void> => apiRequest(`/contact/${id}`, 'DELETE');

export const getBrands = async (): Promise<Brand[]> => apiRequest('/brands');
export const saveBrand = async (brand: Brand): Promise<void> => apiRequest('/brands', 'POST', brand);
export const deleteBrand = async (id: string): Promise<void> => apiRequest(`/brands/${id}`, 'DELETE');

export const getPages = async (): Promise<PageContent[]> => apiRequest('/pages');
export const getPageBySlug = async (slug: string): Promise<PageContent | undefined> => {
    const pages = await getPages();
    return pages.find(p => p.slug === slug);
};
export const savePage = async (page: PageContent): Promise<void> => apiRequest('/pages', 'POST', page);
export const deletePage = async (id: string): Promise<void> => apiRequest(`/pages/${id}`, 'DELETE');

export const getBlogPosts = async (): Promise<BlogPost[]> => apiRequest('/blog');
export const getBlogPostBySlug = async (slug: string): Promise<BlogPost | undefined> => {
    const posts = await getBlogPosts();
    return posts.find(p => p.slug === slug);
};
export const saveBlogPost = async (post: BlogPost): Promise<void> => apiRequest('/blog', 'POST', post);
export const deleteBlogPost = async (id: string): Promise<void> => apiRequest(`/blog/${id}`, 'DELETE');

export const getCoupons = async (): Promise<Coupon[]> => apiRequest('/coupons');
export const saveCoupon = async (coupon: Coupon): Promise<void> => apiRequest('/coupons', 'POST', coupon);
export const deleteCoupon = async (id: string): Promise<void> => apiRequest(`/coupons/${id}`, 'DELETE');
export const validateCoupon = async (code: string, total: number): Promise<Coupon | null> => {
    const coupons = await getCoupons();
    return coupons.find(c => c.code === code && c.isActive) || null;
};
